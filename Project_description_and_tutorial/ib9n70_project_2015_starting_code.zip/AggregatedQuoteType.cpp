// My University number is: *** to be filled in ***
#include "AggregatedQuoteType.hpp"

PriceType AggregatedQuoteType::get_price() const
{
	return 0.0;
}

VolumeType AggregatedQuoteType::get_volume() const
{
	return 0u;
}

unsigned long AggregatedQuoteType::get_number_of_orders() const
{
	return 0u;
}


