// My University number is: *** to be filled in ***
#ifndef CLOB_SHARED_HPP
#define CLOB_SHARED_HPP

enum class SellBuyType {SELL, BUY};
enum class OrderStatusType {ACTIVE, FILLED, CANCELLED, EXPIRED};

typedef unsigned long OrderIdentifierType;
typedef double PriceType;
typedef unsigned long VolumeType;
typedef unsigned long TimeType;




#endif // CLOB_SHARED_HPP
