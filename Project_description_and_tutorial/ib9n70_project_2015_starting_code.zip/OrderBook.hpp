// My University number is: *** to be filled in ***
#ifndef ORDER_BOOK_HPP
#define ORDER_BOOK_HPP

#include <vector>
#include <ostream>

#include "CLOB_shared.hpp"
#include "AggregatedQuoteType.hpp"

class OrderBook
{
	public:
		
		OrderBook ();
		
		bool open (PriceType tick_size, PriceType tolerance, std::ostream &log);
		
		bool close ();
		
		bool submit_order (OrderIdentifierType order_id, SellBuyType sb, PriceType price, VolumeType volume);
		
		bool cancel_order (OrderIdentifierType order_id);
		
		void print_order_info (std::ostream & where, OrderIdentifierType order_id) const;
		
		std::string format_price (PriceType price) const;
		
		std::vector<AggregatedQuoteType> get_aggregated_order_book(SellBuyType which_side) const;
		
		// anything else that might be useful?
		
	private:
		
		// up to you...
};



#endif // ORDER_BOOK_HPP
