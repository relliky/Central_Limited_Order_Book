#ifndef VISUALISE_HELPER_HPP
#define VISUALISE_HELPER_HPP

#include "visualise.hpp"

void display_aggregate_order_book(const OrderBook & ob);

#endif
