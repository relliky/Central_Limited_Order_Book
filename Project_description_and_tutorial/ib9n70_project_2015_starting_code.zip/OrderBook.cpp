// My University number is: *** to be filled in ***
#include "OrderBook.hpp"

OrderBook::OrderBook ()
// : ...
{
	// ...
}

bool OrderBook::open (PriceType tick_size, PriceType tolerance, std::ostream &log)
{
	// ...
	return false;
}

bool OrderBook::close ()
{
	// ...
	return false;
}

bool OrderBook::submit_order (OrderIdentifierType order_id, SellBuyType sb, PriceType price, VolumeType volume)
{
	// ...
	return false;
}

bool OrderBook::cancel_order (OrderIdentifierType order_id)
{
	// ...
	return false;
}

void OrderBook::print_order_info (std::ostream & where, OrderIdentifierType order_id) const
{
	// ...
}

std::string OrderBook::format_price (PriceType price) const
{
	// ...
	return std::string("");
}

std::vector<AggregatedQuoteType> OrderBook::get_aggregated_order_book(SellBuyType which_side) const
{
	std::vector<AggregatedQuoteType> ret;
	// ...
	return ret;
}


