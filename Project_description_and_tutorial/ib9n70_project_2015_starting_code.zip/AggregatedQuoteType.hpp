// My University number is: *** to be filled in ***
#ifndef AGGREGATED_QUOTE_TYPE_HPP
#define AGGREGATED_QUOTE_TYPE_HPP

#include "CLOB_shared.hpp"

class AggregatedQuoteType
{
	public:
		PriceType get_price() const;
		VolumeType get_volume() const;
		unsigned long get_number_of_orders() const;
		// your other members here
	private:
		// your members here
};



#endif // AGGREGATED_QUOTE_TYPE_HPP
